#include "../include/listaExposiciones.h"

struct rep_listaexposiciones
{
    TExposicion exposicion;
    rep_listaexposiciones* sig;
};


TListaExposiciones crearTListaExposicionesVacia(){ 
    TListaExposiciones nueva = new rep_listaexposiciones;
    nueva->exposicion = NULL;
    nueva->sig =  NULL;
    return nueva;
 }

// Simplificacion de fecha Menor
bool fechaMenor(TFecha fecha1, TFecha fecha2) {

    if (  compararTFechas(fecha1,fecha2)!=0  && compararTFechas(fecha1,fecha2)==-1 )
    {
        return true;
    } else return false;
}


void agregarExposicionTListaExposiciones(TListaExposiciones &listaExposiciones, TExposicion expo){

        if (listaExposiciones == NULL)
        {
            listaExposiciones = crearTListaExposicionesVacia();
        }
        
       if (listaExposiciones->exposicion == NULL)
       {
          listaExposiciones->exposicion = expo;
       } else if (fechaMenor(fechaInicioTExposicion(listaExposiciones->exposicion),fechaInicioTExposicion(expo))==false)  {
            TListaExposiciones principio = crearTListaExposicionesVacia();
            principio->exposicion = expo;
            principio->sig = listaExposiciones;
            listaExposiciones = principio;
        } else {
        TListaExposiciones pivot = listaExposiciones;
        while (pivot->sig != NULL && fechaMenor(fechaInicioTExposicion(pivot->sig->exposicion),fechaInicioTExposicion(expo))==true)
        {
           pivot =  pivot->sig;
        }

        if (pivot->sig == NULL)
        {   
            if (fechaMenor(fechaInicioTExposicion(pivot->exposicion),fechaInicioTExposicion(expo))==false)
            {
            TListaExposiciones nueva;
            nueva = crearTListaExposicionesVacia();
            nueva->exposicion = expo;
            nueva->sig = pivot;
            pivot= nueva;
            listaExposiciones = pivot;
            } else 
           {
            pivot->sig = crearTListaExposicionesVacia();
            pivot->sig->exposicion = expo;
            pivot->sig->sig = NULL;}
        } else {
            TListaExposiciones nueva;
            nueva = crearTListaExposicionesVacia();
            nueva->exposicion = expo;
            nueva->sig = pivot->sig;
            pivot->sig = nueva;
        }

       }
       
    }
    


bool perteneceExposicionTListaExposiciones(TListaExposiciones listaExposiciones, int idExpo){ 
    bool resultado = false;
    if (listaExposiciones != NULL)
    {
       if(listaExposiciones->exposicion != NULL) 
       {
        while (listaExposiciones != NULL && resultado == false)
       {
        if (idTExposicion(listaExposiciones->exposicion)== idExpo)
        {
            resultado = true;
        }
        listaExposiciones = listaExposiciones->sig;
       }}
       
    } 
    return resultado;
    
 }

TExposicion obtenerExposicionTListaExposiciones(TListaExposiciones listaExposiciones, int idExpo){ 

  while (listaExposiciones != NULL && idTExposicion(listaExposiciones->exposicion)!= idExpo )
  {
    listaExposiciones = listaExposiciones->sig;
  }
 if (listaExposiciones->exposicion != NULL)
 {
   return listaExposiciones->exposicion;
 } else return NULL;
 
  
}

bool esVaciaTListaExposiciones(TListaExposiciones listaExposiciones){ 
    if (listaExposiciones == NULL)
    {
        return true;
    } else {
        if (listaExposiciones->exposicion == NULL && listaExposiciones->sig == NULL )
        {
            return true;
        } else return false;
        
    }
    
 }






void imprimirTListaExposiciones(TListaExposiciones listaExposiciones){

if (listaExposiciones != NULL)
{
   while (listaExposiciones != NULL)
   {
    if (listaExposiciones->exposicion != NULL)
    {
        imprimirTExposicion(listaExposiciones->exposicion);
    }
    listaExposiciones = listaExposiciones->sig;
   }
   
}







}

void liberarTListaExposiciones(TListaExposiciones &listaExposiciones, bool liberarExposiciones){
if (listaExposiciones!= NULL )
{
    TListaExposiciones pivot;
    
   while (listaExposiciones != NULL )
   {
    pivot = listaExposiciones;
    listaExposiciones = listaExposiciones->sig;
    if ( liberarExposiciones == true)
     {
       liberarTExposicion(pivot->exposicion);
     
    }
     delete pivot;
     pivot = NULL;

    }
    
   
   }
   
    
}


TListaExposiciones obtenerExposicionesFinalizadas(TListaExposiciones &listaExposiciones, TFecha fecha){ 
if (listaExposiciones!=NULL)
{
TListaExposiciones pivot,borrar,inicio,nueva;
pivot = listaExposiciones;
nueva = crearTListaExposicionesVacia();
inicio = nueva;
while (pivot->sig != NULL)
{
    if (compararTFechas(fechaFinTExposicion(pivot->sig->exposicion),fecha)==-1)
    {  
       nueva->sig = crearTListaExposicionesVacia();
       nueva->sig->exposicion = pivot->sig->exposicion;
       borrar = pivot->sig;
       pivot->sig = pivot->sig->sig;
       nueva = nueva->sig;
       delete borrar;
       borrar = NULL;
        
    } else pivot = pivot->sig;   
}

nueva = inicio;
if (compararTFechas(fechaFinTExposicion(listaExposiciones->exposicion),fecha)==-1)
{
    nueva->exposicion = listaExposiciones->exposicion;
    borrar = listaExposiciones;
    listaExposiciones = listaExposiciones->sig;
    delete borrar;
    borrar = NULL;
} else {
    if (nueva->sig != NULL)
    {
    borrar = nueva;
    nueva = nueva->sig;

    delete borrar;
    borrar = NULL;
    } else {
        delete nueva;
        nueva = NULL;
    }
}


return nueva;

} 
return NULL;
 }              




TListaExposiciones obtenerExposicionesActivas(TListaExposiciones &listaExposiciones, TFecha fecha){ 
if (listaExposiciones!=NULL)
{
TListaExposiciones pivot,borrar,inicio,nueva;
pivot = listaExposiciones;
nueva = crearTListaExposicionesVacia();
inicio = nueva;
while (pivot->sig != NULL)
{
    if ((compararTFechas(fechaInicioTExposicion(pivot->sig->exposicion),fecha)==-1 || compararTFechas(fechaInicioTExposicion(pivot->sig->exposicion),fecha)==0) && (compararTFechas(fechaFinTExposicion(pivot->sig->exposicion),fecha)==1 || compararTFechas(fechaFinTExposicion(pivot->sig->exposicion),fecha)==0))
    {  
       nueva->sig = crearTListaExposicionesVacia();
       nueva->sig->exposicion = pivot->sig->exposicion;
       borrar = pivot->sig;
       pivot->sig = pivot->sig->sig;
       nueva = nueva->sig;
       delete borrar;
       borrar = NULL;
        
    } else pivot = pivot->sig;   
}
nueva = inicio;
if ((compararTFechas(fechaInicioTExposicion(listaExposiciones->exposicion),fecha)==-1 || compararTFechas(fechaInicioTExposicion(listaExposiciones->exposicion),fecha)==0) && (compararTFechas(fechaFinTExposicion(listaExposiciones->exposicion),fecha)==1 || compararTFechas(fechaFinTExposicion(listaExposiciones->exposicion),fecha)==0))
{
    nueva->exposicion = listaExposiciones->exposicion;
    borrar = listaExposiciones;
    listaExposiciones = listaExposiciones->sig;
    delete borrar;
    borrar = NULL;
} else {
   if (nueva->sig != NULL)
    {
    borrar = nueva;
    nueva = nueva->sig;

    delete borrar;
    borrar = NULL;
    }
}


return nueva;

} 
return NULL;




}

bool esCompatibleTListaExposiciones(TListaExposiciones listaExposiciones, TExposicion expo){ 
    bool compatibles = true;
    if (listaExposiciones != NULL)
    {
        
        while (listaExposiciones != NULL && compatibles)
        {
            if (!sonExposicionesCompatibles(listaExposiciones->exposicion, expo))
            {
                compatibles = false;
            }
           listaExposiciones = listaExposiciones->sig; 
        }
        
    }
    return compatibles;
 }

TListaExposiciones unirListaExposiciones(TListaExposiciones listaExpo1, TListaExposiciones listaExpo2){ 
    if (listaExpo1 != NULL || listaExpo2 != NULL)
    {
    TListaExposiciones nueva = crearTListaExposicionesVacia();
    TListaExposiciones pivot1,clon1,clon2;
    pivot1 = nueva;
    clon1 = listaExpo1;
    clon2 = listaExpo2;
    if (clon1 != NULL)
    {
       while (clon1 != NULL)
       {
        nueva->exposicion = clon1->exposicion;
        if (clon1->sig != NULL)
        {
            nueva->sig = crearTListaExposicionesVacia();
            nueva = nueva->sig;
        }
        clon1 = clon1->sig;
       }
    if (clon2 != NULL)
    { 
      TListaExposiciones nueva2 = crearTListaExposicionesVacia();
      TListaExposiciones pivot2 = nueva2;
        while (clon2 != NULL)
        {
           nueva2->exposicion = clon2->exposicion;
            if (clon2->sig != NULL)
        {
            nueva2->sig = crearTListaExposicionesVacia();
            nueva2 = nueva2->sig;
        }
           
           clon2 = clon2->sig;
        }
    if (fechaMenor(fechaInicioTExposicion(nueva2->exposicion),fechaInicioTExposicion(pivot1->exposicion))==true)
    {
        nueva2->sig = pivot1;
        pivot1 = pivot2;
        return pivot1;
    } else {
        nueva->sig = pivot2;
        return pivot1;
    }
        
        
        
    }
    nueva = pivot1;
    return nueva;
    
    } else if (clon1 == NULL) {

        if (clon2 != NULL)
    {
        while (clon2 != NULL)
        {
            nueva->exposicion = clon2->exposicion;
            if (clon2->sig != NULL)
            {
                nueva->sig = crearTListaExposicionesVacia();
                nueva = nueva->sig;
            }
            clon2 = clon2->sig; 
        }
        nueva = pivot1;
        return nueva;
    } else { 

        delete nueva;
        nueva = NULL;
        pivot1 = NULL;
        return nueva;
    }
    
    
 }    }
return NULL;
}

