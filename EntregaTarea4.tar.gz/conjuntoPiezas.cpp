#include "../include/conjuntoPiezas.h"

struct rep_conjuntopiezas
{
   int cota;
   int tope = 0;
   int* array;
};
 

TConjuntoPiezas crearTConjuntoPiezas(int cantMax){ 
  
  TConjuntoPiezas conjunto = new rep_conjuntopiezas;
   conjunto->cota = cantMax;
   conjunto->array = new int[cantMax];
  for (int i = 0; i < cantMax; i++)
  {
   conjunto->array[i] = -1;
  }
 
  return conjunto;
  
 }

bool esVacioTConjuntoPiezas(TConjuntoPiezas c){
   return c->tope == 0;
  }

void insertarTConjuntoPiezas(TConjuntoPiezas &c, int id){
  if (id < c->cota)
  {
   if (c->array[id] == -1)
   {
      c->array[id] = id;
      ++c->tope;
   }
   
  }
  
}

void borrarDeTConjuntoPiezas(TConjuntoPiezas &c, int id){
   if (id < c->cota)
   {
  
      if (c->array[id]!=-1)
   {
      c->array[id] = -1;
      --c->tope;
   }
   }
   
  
   
}

bool perteneceTConjuntoPiezas(TConjuntoPiezas c, int id){
   if (id < c->cota)
   {
      return c->array[id] != -1; 
   } else return false;
    
   }

int cardinalTConjuntoPiezas(TConjuntoPiezas c){ return c->tope; }

int cantMaxTConjuntoPiezas(TConjuntoPiezas c){ return c->cota; }

void imprimirTConjuntoPiezas(TConjuntoPiezas c){
   if (c != NULL)
   {
      for (int i = 0; i < c->cota; i++)
      {  
         if (c->array[i] != -1)
         {
             printf("%d ",c->array[i]);
         }
      }
      printf("\n");
   }
   
}

void liberarTConjuntoPiezas(TConjuntoPiezas &c){
 if (c!=NULL)
 { 
   delete[] c->array;
   c->array = NULL;  
   delete c;
   c = NULL;
 }
 
}

TConjuntoPiezas unionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){
   TConjuntoPiezas nuevo;
   nuevo = crearTConjuntoPiezas(c1->cota);
   for (int i = 0; i < c1->cota; i++)
   {  
      if (c1->array[i] != -1)
      {
        insertarTConjuntoPiezas(nuevo,c1->array[i]);
      }
   }

   for (int x = 0; x < c2->cota; x++)
   {
      if (c2->array[x] != -1 && nuevo->array[x] == -1)
      {
       insertarTConjuntoPiezas(nuevo,c2->array[x]);
      }
      
   }
   
   return nuevo;
 }

TConjuntoPiezas interseccionTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ 
   TConjuntoPiezas nuevo;
   nuevo = crearTConjuntoPiezas(c1->cota);
   for (int i = 0; i < c1->cota; i++)
   {
      if( c1->array[i]!= -1 && (c1->array[i] == c2->array[i])) {
       insertarTConjuntoPiezas(nuevo,c2->array[i]);
      };
   }
   return nuevo;
 }

TConjuntoPiezas diferenciaTConjuntoPiezas(TConjuntoPiezas c1, TConjuntoPiezas c2){ 
   TConjuntoPiezas nuevo;
   nuevo = crearTConjuntoPiezas(c1->cota);
   for (int y = 0; y < c1->cota; y++)
   {
      if (c1->array[y]!=c2->array[y] && c1->array[y]!=-1)
      {
         insertarTConjuntoPiezas(nuevo,c1->array[y]);
      };
      
   }
   return nuevo;
 }

