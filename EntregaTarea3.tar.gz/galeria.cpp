#include "../include/galeria.h"

struct rep_galeria {
TFecha fecha;
TListaExposiciones  pasadas;
TListaExposiciones  presente;
TListaExposiciones  futura;
TColeccionPiezas  piezas;
};

TGaleria crearTGaleria(TFecha fecha){ 
    TGaleria galeria = new rep_galeria;
    galeria->fecha = fecha;
    galeria->futura = NULL;
    galeria->pasadas = NULL;
    galeria->presente = NULL;
    galeria->piezas = NULL;
    return galeria;  
 }

void agregarPiezaTGaleria(TGaleria galeria, TPieza pieza){
    if (galeria != NULL && pieza != NULL)
    { 
       insertarPiezaColeccionPiezas(galeria->piezas,pieza);
    }
    
}

void agregarExposicionTGaleria(TGaleria galeria, TExposicion expo){
    if (galeria != NULL)
    {
       if (expo != NULL){
        if ((compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==0 || compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==1) )
        {  
            if (compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==1)
            {   

                agregarExposicionTListaExposiciones(galeria->futura,expo); 
            } else agregarExposicionTListaExposiciones(galeria->presente,expo); 
        } else if (compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==1 || compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==0) {
            agregarExposicionTListaExposiciones(galeria->presente,expo);
        } else if (compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==-1) {
            agregarExposicionTListaExposiciones(galeria->pasadas,expo);
        }
       }  
    }
}

void agregarPiezaAExposicionTGaleria(TGaleria galeria, int idPieza, int idExpo){
    if (galeria != NULL)
    {
     if (perteneceExposicionTListaExposiciones(galeria->futura,idExpo))
     {  
        TExposicion exposicion;
        exposicion = obtenerExposicionTListaExposiciones(galeria->futura,idExpo);
        agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));

     } else if (perteneceExposicionTListaExposiciones(galeria->pasadas,idExpo))
     {
        TExposicion exposicion;
        exposicion = obtenerExposicionTListaExposiciones(galeria->pasadas,idExpo);
        agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));

     } else if (perteneceExposicionTListaExposiciones(galeria->presente,idExpo))
     {
         TExposicion exposicion;
         exposicion = obtenerExposicionTListaExposiciones(galeria->presente,idExpo);
         agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));
     }
     
     
     
        
    
    }
    


}

void avanzarAFechaTGaleria(TGaleria galeria, TFecha fecha){

if (galeria != NULL)
{
liberarTFecha(galeria->fecha);
galeria->fecha = fecha;

TListaExposiciones copia1,copia2,borrar,unir;
copia1 = obtenerExposicionesFinalizadas(galeria->futura,fecha);
copia2 = obtenerExposicionesFinalizadas(galeria->presente,fecha);
unir = unirListaExposiciones(copia1,copia2);
liberarTListaExposiciones(copia1,false);
liberarTListaExposiciones(copia2,false);
borrar = galeria->pasadas;
galeria->pasadas = unirListaExposiciones(galeria->pasadas, unir);
liberarTListaExposiciones(unir,false);
liberarTListaExposiciones(borrar,false);

copia1 = obtenerExposicionesActivas(galeria->futura, fecha);
copia2 = obtenerExposicionesActivas(galeria->presente,fecha);
unir = unirListaExposiciones(copia1,copia2);
borrar = galeria->presente;
galeria->presente =  unir;
liberarTListaExposiciones(borrar,false);
liberarTListaExposiciones(copia2,false);
liberarTListaExposiciones(copia1,false);


}
}


void imprimirExposicionesFinalizadasTGaleria(TGaleria galeria){
    if (galeria != NULL && galeria->pasadas != NULL)
    {
       imprimirTListaExposiciones(galeria->pasadas);
    }
    
}

void imprimirExposicionesActivasTGaleria(TGaleria galeria){
      if (galeria != NULL && galeria->presente != NULL)
    {
       imprimirTListaExposiciones(galeria->presente);
    }
}

void imprimirExposicionesFuturasTGaleria(TGaleria galeria){
      if (galeria != NULL && galeria->futura != NULL)
    {
        imprimirTListaExposiciones(galeria->futura);
    }
}

bool esCompatibleExposicionTGaleria(TGaleria galeria, TExposicion expo){ 
bool compatible = false;

if (galeria != NULL)
{
if( esCompatibleTListaExposiciones(galeria->futura,expo) && esCompatibleTListaExposiciones(galeria->presente,expo) && esCompatibleTListaExposiciones(galeria->pasadas,expo)) {
return !compatible;
} 
return compatible;   
} else return 0;
 }

void liberarTGaleria(TGaleria &galeria){
    if (galeria != NULL)
    {
        liberarColeccionPiezas(galeria->piezas);
        liberarTListaExposiciones(galeria->futura,true);
        liberarTListaExposiciones(galeria->pasadas,true );
        liberarTListaExposiciones(galeria->presente,true);
        liberarTFecha(galeria->fecha);
        delete galeria;
        galeria = NULL;
    }
    
}
