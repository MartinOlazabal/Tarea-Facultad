#include "../include/galeria.h"

struct rep_galeria {
TFecha fecha;
TListaExposiciones  pasadas;
TListaExposiciones  presente;
TListaExposiciones  futura;
TColeccionPiezas  piezas;
TVisitaDia visitiadia;
THashVisitaDia visitahash;
};

TGaleria crearTGaleria(TFecha fecha){ 
    TGaleria galeria = new rep_galeria;
    galeria->fecha = fecha;
    galeria->futura = NULL;
    galeria->pasadas = NULL;
    galeria->presente = NULL;
    galeria->piezas = NULL;
    galeria->visitahash = crearTHashVisitaDia(CANT_ESTIMADA_VISITA_DIA_PASADAS);
    galeria->visitiadia = crearTVisitaDia(fecha,MAX_GRUPOS_VISITA_DIA);
    return galeria;  
 }

void agregarPiezaTGaleria(TGaleria galeria, TPieza pieza){
    if (galeria != NULL && pieza != NULL)
    { 
       insertarPiezaColeccionPiezas(galeria->piezas,pieza);
    }
    
}

void agregarExposicionTGaleria(TGaleria galeria, TExposicion expo){
    if (galeria != NULL)
    {
       if (expo != NULL){
        if ((compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==0 || compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==1) )
        {  
            if (compararTFechas(fechaInicioTExposicion(expo),galeria->fecha)==1)
            {   

                agregarExposicionTListaExposiciones(galeria->futura,expo); 
            } else agregarExposicionTListaExposiciones(galeria->presente,expo); 
        } else if (compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==1 || compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==0) {
            agregarExposicionTListaExposiciones(galeria->presente,expo);
        } else if (compararTFechas(fechaFinTExposicion(expo),galeria->fecha)==-1) {
            agregarExposicionTListaExposiciones(galeria->pasadas,expo);
        }
       }  
    }
}

void agregarPiezaAExposicionTGaleria(TGaleria galeria, int idPieza, int idExpo){
    if (galeria != NULL)
    {
     if (perteneceExposicionTListaExposiciones(galeria->futura,idExpo))
     {  
        TExposicion exposicion;
        exposicion = obtenerExposicionTListaExposiciones(galeria->futura,idExpo);
        agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));

     } else if (perteneceExposicionTListaExposiciones(galeria->pasadas,idExpo))
     {
        TExposicion exposicion;
        exposicion = obtenerExposicionTListaExposiciones(galeria->pasadas,idExpo);
        agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));

     } else if (perteneceExposicionTListaExposiciones(galeria->presente,idExpo))
     {
         TExposicion exposicion;
         exposicion = obtenerExposicionTListaExposiciones(galeria->presente,idExpo);
         agregarATExposicion(exposicion,obtenerPiezaColeccionPiezas(galeria->piezas,idPieza));
     }
     
     
     
        
    
    }
    


}

void avanzarAFechaTGaleria(TGaleria galeria, TFecha fecha){

if (galeria != NULL)
{

TVisitaDia aux = galeria->visitiadia;
agregarVisitaDiaTHashVisitaDia(galeria->visitahash,aux);
galeria->fecha = fecha;
galeria->visitiadia = crearTVisitaDia(fecha,MAX_GRUPOS_VISITA_DIA);

TListaExposiciones copia1,copia2,borrar,unir;
copia1 = obtenerExposicionesFinalizadas(galeria->futura,fecha);
copia2 = obtenerExposicionesFinalizadas(galeria->presente,fecha);
unir = unirListaExposiciones(copia1,copia2);
liberarTListaExposiciones(copia1,false);
liberarTListaExposiciones(copia2,false);
borrar = galeria->pasadas;
galeria->pasadas = unirListaExposiciones(galeria->pasadas, unir);
liberarTListaExposiciones(unir,false);
liberarTListaExposiciones(borrar,false);

copia1 = obtenerExposicionesActivas(galeria->futura, fecha);
copia2 = obtenerExposicionesActivas(galeria->presente,fecha);
unir = unirListaExposiciones(copia1,copia2);
borrar = galeria->presente;
galeria->presente =  unir;
liberarTListaExposiciones(borrar,false);
liberarTListaExposiciones(copia2,false);
liberarTListaExposiciones(copia1,false);
}
}


void imprimirExposicionesFinalizadasTGaleria(TGaleria galeria){
    if (galeria != NULL && galeria->pasadas != NULL)
    {
       imprimirTListaExposiciones(galeria->pasadas);
    }
    
}

void imprimirExposicionesActivasTGaleria(TGaleria galeria){
      if (galeria != NULL && galeria->presente != NULL)
    {
       imprimirTListaExposiciones(galeria->presente);
    }
}

void imprimirExposicionesFuturasTGaleria(TGaleria galeria){
      if (galeria != NULL && galeria->futura != NULL)
    {
        imprimirTListaExposiciones(galeria->futura);
    }
}

bool esCompatibleExposicionTGaleria(TGaleria galeria, TExposicion expo){ 
bool compatible = false;

if (galeria != NULL)
{
if( esCompatibleTListaExposiciones(galeria->futura,expo) && esCompatibleTListaExposiciones(galeria->presente,expo) && esCompatibleTListaExposiciones(galeria->pasadas,expo)) {
return !compatible;
} 
return compatible;   
} else return 0;
 }

void liberarTGaleria(TGaleria &galeria){
    if (galeria != NULL)
    {
        liberarColeccionPiezas(galeria->piezas);
        liberarTListaExposiciones(galeria->futura,true);
        liberarTListaExposiciones(galeria->pasadas,true );
        liberarTListaExposiciones(galeria->presente,true);
        liberarTHashVisitaDia(galeria->visitahash);
        liberarTVisitaDia(galeria->visitiadia);
        delete galeria;
        galeria = NULL;
    }}


// Funciones tarea 4

TConjuntoPiezas piezasEnExposicionTGaleria(TGaleria galeria){
  if (galeria != NULL)
  {
    if (galeria->presente != NULL)
    {
        TConjuntoPiezas nueva = crearTConjuntoPiezas(MAX_PIEZAS);
        int contador = cantidadExposicionesTListaExposiciones(galeria->presente);
        for (int i = 1; i <= contador; i++)
        {
        TExposicion obtener = obtenerNesimaExposicionTListaExposiciones(galeria->presente,i);
        TConjuntoPiezas aux, aux2 = NULL;
        aux = obtenerPiezasTExposicion(obtener);
        aux2 = nueva;
        nueva = unionTConjuntoPiezas(aux,nueva);
        liberarTConjuntoPiezas(aux2);
        } 
        return nueva;
    } else return NULL;
 }
    return NULL;
}




float indiceFelicidadVisitanteTGaleria(TGaleria galeria, TVisitante visitante){
   if (galeria != NULL)
{
   if (visitante != NULL)
   {
    if (obtenerPiezasFavoritasTVisitante(visitante) == NULL || cardinalTConjuntoPiezas(obtenerPiezasFavoritasTVisitante(visitante))==0)
    {
       int felicidad = 1.0;
       return felicidad;
    } else {
       if (galeria->presente != NULL) {
            TConjuntoPiezas nuevo = NULL;
            TConjuntoPiezas aux = piezasEnExposicionTGaleria(galeria);        
            nuevo = interseccionTConjuntoPiezas(aux,obtenerPiezasFavoritasTVisitante(visitante));
            int  estanpiezas = cardinalTConjuntoPiezas(nuevo);
            int  piezasfavoritas = cardinalTConjuntoPiezas(obtenerPiezasFavoritasTVisitante(visitante));
            liberarTConjuntoPiezas(nuevo);
            liberarTConjuntoPiezas(aux);
         
           
            
            if (piezasfavoritas > 0)
            {
                float resultado = (float)estanpiezas/piezasfavoritas;
               
                
                return resultado;
            }
            

    }}
    
   }
   
}
   
   
    return 0.0;
}





void llegaGrupoTGaleria(TGaleria galeria, TGrupoABB grupoABB){
    if (galeria != NULL)
    {  
       encolarGrupoTVisitaDia(galeria->visitiadia,grupoABB);
    }
}

TConjuntoPiezas piezasEnReservaTGaleria(TGaleria galeria){    
    if (galeria != NULL)
    {
        TConjuntoPiezas nuevo = crearTConjuntoPiezas(MAX_PIEZAS);
        TConjuntoPiezas final = crearTConjuntoPiezas(MAX_PIEZAS);
        TConjuntoPiezas aux2,aux3 =  NULL;
        int count = cantidadExposicionesTListaExposiciones(galeria->presente);
        if (galeria->presente != NULL)
        {
            
         for (int i = 0; i < count; i++)
         {
            TExposicion obtener = obtenerNesimaExposicionTListaExposiciones(galeria->presente,i+1);
            aux2 = obtenerPiezasTExposicion(obtener);
            aux3 = nuevo;
            nuevo = unionTConjuntoPiezas(aux2,nuevo);
            liberarTConjuntoPiezas(aux3);
          }

            int count2 = 0;
            while (existePiezaColeccionPiezas(galeria->piezas,count2+1))
            {    
              ++count2;
              if (perteneceTConjuntoPiezas(nuevo,count2)==false)
              {
                insertarTConjuntoPiezas(final,count2);
              }  
                   
            }
            liberarTConjuntoPiezas(nuevo);
            return final;
        }  return final;
    }
    return NULL;
    }


TVisitaDia obtenerVisitaDiaTGaleria(TGaleria galeria, TFecha fecha){
    if (galeria != NULL)
    {
        if (perteneceVisitaDiaTHashVisitaDia(galeria->visitahash,fecha))
        {
            return obtenerVisitaDiaTHashVisitaDia(galeria->visitahash,fecha);
        } else if (galeria->visitiadia!= NULL && compararTFechas(galeria->fecha,fecha)==0)
        {
            return galeria->visitiadia;
        }
    }
    return NULL;
    
}
