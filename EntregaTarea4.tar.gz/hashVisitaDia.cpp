
#include "../include/hashVisitaDia.h"


struct nodoHash {
  nodoHash* sig;
  
  TVisitaDia visita;
};

typedef struct  nodoHash *THash;

struct rep_hashvisitadia {
 nodoHash** tabla;
 int cantidad;
 int cota;
};



// interna funcion hash
int funcionHash(TFecha fecha, int cantEstimadas){
    return (31 * (int) mesTFecha(fecha) + (int) diaTFecha(fecha)) % cantEstimadas;
}

THashVisitaDia crearTHashVisitaDia(int cantEstimadas){
   THashVisitaDia visita = new rep_hashvisitadia;
   visita->cota = cantEstimadas;
   visita->cantidad = 0;
   visita->tabla = new nodoHash*[cantEstimadas];
   for (int i = 0;  i < cantEstimadas; i++)
   {
    visita->tabla[i] = NULL;
   }
   return visita;
 
}

void agregarVisitaDiaTHashVisitaDia(THashVisitaDia hash, TVisitaDia visitaDia){
 if (hash != NULL)
 {  
    
    
    int aux = hash->cota;
    int assign = funcionHash(fechaTVisitaDia(visitaDia),aux);
    if (hash->tabla[assign] == NULL)
    {
        hash->tabla[assign] = new nodoHash;
        ++hash->cantidad;

        hash->tabla[assign]->sig = NULL;
        hash->tabla[assign]->visita = visitaDia;
    } else {
        ++hash->cantidad;
        THash aux;
        aux = hash->tabla[assign];
        hash->tabla[assign] = new nodoHash;
        hash->tabla[assign]->visita = visitaDia;
        hash->tabla[assign]->sig = aux;
    }
    
 }
 
}

void imprimirTHashVisitaDia(THashVisitaDia hash){
    if (hash != NULL)
    {
        for (int i = 0; i < hash->cota; i++)
        {
           if (hash->tabla[i] != NULL)
           {
            printf("Elementos en la posicion %d de la tabla:\n",i);
            THash  aux = hash->tabla[i];
            while (aux != NULL)
            {
                
                imprimirTVisitaDia(aux->visita);
                aux = aux->sig;
            }
           } else {
            printf("No hay elementos guardados la posicion %d de la tabla.\n",i);
           }
           
        }
        
    }
    
}

TVisitaDia obtenerVisitaDiaTHashVisitaDia(THashVisitaDia hash, TFecha fecha){
    if (hash != NULL)
    {
        int indice = funcionHash(fecha, hash->cota);
        if (hash->tabla[indice] != NULL)
        {    
            THash aux =  hash->tabla[indice];
            while (aux != NULL && compararTFechas(fecha,fechaTVisitaDia(aux->visita))!=0)
            {
                aux = aux->sig;
            }
            if (aux != NULL)
            {
               return aux->visita;
            } else return NULL;
            
            
            
        }
        
    } 
    return NULL;
    
}

bool perteneceVisitaDiaTHashVisitaDia(THashVisitaDia hash, TFecha fecha){
        if (hash != NULL)
    {
        int indice = funcionHash(fecha, hash->cota);
        if (hash->tabla[indice] != NULL)
        {
            THash aux =  hash->tabla[indice];
            while (aux != NULL && compararTFechas(fecha,fechaTVisitaDia(aux->visita))!=0)
            {
                aux = aux->sig;
            }
            return aux != NULL;
        }
        
        
    
}return false;}

void liberarTHashVisitaDia(THashVisitaDia &hash){
    if (hash != NULL)
    {
        for (int i = 0; i < hash->cota; i++)
        {
          if (hash->tabla[i] != NULL)
          {
            while (hash->tabla[i] != NULL)
            {
                THash aux = hash->tabla[i];
                hash->tabla[i] = hash->tabla[i]->sig;
                liberarTVisitaDia(aux->visita);
                delete aux;
                aux = NULL;
            }
            hash->tabla[i] = NULL;
          }   
        }
        delete[] hash->tabla;
        hash->tabla = NULL;
        delete hash;
        hash = NULL;
        
    }
    
}
