#include "../include/visitaDia.h"

 struct rep_lista {
  TGrupoABB grupo;
  rep_lista * sig;
  rep_lista * ant;
 };

typedef struct rep_lista *Lista;

 struct rep_visitadia {
  Lista inicio, final;
  TFecha fecha;
  int cantidadgrupos;
};

bool esListaVacia(TVisitaDia visitaDia) {
return visitaDia->inicio == NULL;
}

TVisitaDia crearTVisitaDia(TFecha fecha){ 
 TVisitaDia visita = new rep_visitadia;
 visita->fecha =  fecha;
 visita->inicio = NULL;
 visita->cantidadgrupos = 0;
 visita->final = NULL;
 return visita;
 }

void encolarGrupoTVisitaDia(TVisitaDia &visitaDia, TGrupoABB grupo){
  if (visitaDia->inicio == NULL)
  {
    visitaDia->inicio = new rep_lista;
    visitaDia->inicio->sig = NULL;
    visitaDia->inicio->ant = NULL;
    visitaDia->inicio->grupo = grupo;
    visitaDia->final = visitaDia->inicio;
    ++visitaDia->cantidadgrupos;
  } else {
   visitaDia->inicio->ant = new rep_lista;
   visitaDia->inicio->ant->grupo = grupo;
   visitaDia->inicio->ant->sig = visitaDia->inicio;
   visitaDia->inicio->ant->ant = NULL;
   visitaDia->inicio = visitaDia->inicio->ant;
   ++visitaDia->cantidadgrupos;

  }
  


}

int cantidadGruposTVisitaDia(TVisitaDia visitaDia){
   return visitaDia->cantidadgrupos; }

void imprimirVisitaDia(TVisitaDia visitaDia){
 if (visitaDia!= NULL)
 {
  printf("Visita para dia: ");
imprimirTFecha(visitaDia->fecha);
printf("\n");
Lista pivot;
pivot = visitaDia->inicio;
while (pivot != NULL)
{
  imprimirTGrupoABB(pivot->grupo);
  pivot = pivot->sig;
}

 }
  


}

TGrupoABB desencolarGrupoTVisitaDia(TVisitaDia &visitaDia){ 
TGrupoABB grupo;
grupo = visitaDia->final->grupo;
Lista lista = visitaDia->final;
visitaDia->final = visitaDia->final->ant;
if (visitaDia->final != NULL)
{
 visitaDia->final->sig = NULL;
} else {
  visitaDia->inicio = visitaDia->final = NULL;
}
delete lista;
lista = NULL;
return grupo;


 }

void liberarTVisitaDia(TVisitaDia &visitaDia){
if (visitaDia != NULL)
{
  while (visitaDia->inicio != NULL)
{
  Lista aux = visitaDia->inicio;
  visitaDia->inicio = visitaDia->inicio->sig;
  liberarTGrupoABB(aux->grupo);
  delete aux;
  aux = NULL;
  
}
liberarTFecha(visitaDia->fecha);
delete visitaDia;
visitaDia = NULL;
}




}

