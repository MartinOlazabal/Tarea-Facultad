#include "../include/exposicion.h"

struct rep_exposicion {
int id;
TFecha inicio, fin;
TConjuntoPiezas piezas;
};

TExposicion crearTExposicion(int idExp, TFecha ini, TFecha fin, int cantMax){ 
    TExposicion exposicion = new rep_exposicion;
    exposicion->id = idExp;
    exposicion->inicio = ini;
    exposicion->fin = fin;
    exposicion->piezas = crearTConjuntoPiezas(cantMax);
    return exposicion;
    
 }

void agregarATExposicion(TExposicion &exp, TPieza p){
    if (!perteneceTConjuntoPiezas(exp->piezas,idTPieza(p)))
    {
        insertarTConjuntoPiezas(exp->piezas, idTPieza(p));
    }
    
}

bool perteneceATExposicion(TExposicion exp, TPieza p){ 
    return perteneceTConjuntoPiezas(exp->piezas,idTPieza(p));
 }

int idTExposicion(TExposicion exp){ 
    if (exp != NULL)
    {
        return exp->id;
    } else return 0;
    
    
 }

void imprimirTExposicion(TExposicion exp){
    if (exp != NULL)
    {
        printf("Exposicion #%d del ",exp->id);
        imprimirTFecha(exp->inicio);
        printf(" al ");
        imprimirTFecha(exp->fin);
        printf("\nPiezas: ");
        imprimirTConjuntoPiezas(exp->piezas);
    }
    



}

TFecha fechaInicioTExposicion(TExposicion exp){ return exp->inicio; }

TFecha fechaFinTExposicion(TExposicion exp){ return exp->fin; }




bool sonExposicionesCompatibles(TExposicion exp1, TExposicion exp2){
bool compatibles = true;
    if ((compararTFechas(exp1->inicio,exp2->inicio)==0) || (compararTFechas(exp1->inicio,exp2->inicio)==1
     && compararTFechas(exp1->inicio,exp2->fin)==-1) || compararTFechas(exp1->fin,exp2->fin)==0 || 
     ((compararTFechas(exp1->inicio,exp2->inicio)==-1 && compararTFechas(exp1->fin,exp2->inicio)==1) || (compararTFechas(exp1->fin,exp2->inicio)==0)))
    {
     TConjuntoPiezas conjunto = interseccionTConjuntoPiezas(exp1->piezas,exp2->piezas);
      if (cardinalTConjuntoPiezas(conjunto) == 0)
      {
        liberarTConjuntoPiezas(conjunto);
       return compatibles;
      } else {
        liberarTConjuntoPiezas(conjunto);
        compatibles = false;
        return compatibles;
      }
     } else {  return compatibles;}
    }
    


 

void liberarTExposicion(TExposicion &exp){ 
    if (exp != NULL)
    {
    liberarTConjuntoPiezas(exp->piezas); 
    liberarTFecha(exp->inicio);
    liberarTFecha(exp->fin);
    delete exp;
    exp = NULL;
    }
    
 
    }
  
