#include "../include/visitaDia.h"

 struct rep_raiz {
  TGrupoABB dato;
  int orden;

 };

typedef struct rep_raiz *TRaiz;

struct rep_visitadia{
int tope;
int maximo;
TFecha fecha;
TRaiz* array;
bool invertido;
};

TVisitaDia crearTVisitaDia(TFecha fecha, int N){
  TVisitaDia  nueva = new rep_visitadia; 
  nueva->array = new TRaiz[N+1];
  nueva->fecha = fecha;
  nueva->tope = 0;
  nueva->maximo = N;
  nueva->invertido = false;
  for (int i = 0; i < (N+1); i++)
  {
    nueva->array[i] = NULL;
  }
  return nueva;
}

// Filtrado de menor a mayor
void filtradoAscendente(TVisitaDia &visitadia, int pos) {

if (pos > 1 && edadPromedioTGrupoABB(visitadia->array[pos]->dato) < edadPromedioTGrupoABB(visitadia->array[pos/2]->dato))
{
  
  TRaiz pivot = visitadia->array[pos];
  visitadia->array[pos] = visitadia->array[pos/2];
  visitadia->array[pos/2] = pivot;
 
  filtradoAscendente(visitadia, pos/2);
} }

// Filtrado de mayor a menor
void filtradoAscendenteInvertido(TVisitaDia &visitadia, int pos) {

if (pos > 1 && edadPromedioTGrupoABB(visitadia->array[pos]->dato) > edadPromedioTGrupoABB(visitadia->array[(pos/2)]->dato))
{
  TRaiz pivot = visitadia->array[pos];
  visitadia->array[pos] = visitadia->array[pos/2];
  visitadia->array[pos/2] = pivot;
  
  filtradoAscendenteInvertido(visitadia, pos/2);
} }


// Encolar de menor a mayor
void encolarGrupoTVisitaDia(TVisitaDia &visita, TGrupoABB grupo){

 if (visita!=NULL)
 {
    if (visita->array[1]==NULL)
    {
      TRaiz nuevo = new rep_raiz;
      nuevo->dato = grupo;
      nuevo->orden = idGrupo(grupo);
      visita->array[1] = nuevo;
      ++visita->tope;

    } else {
      TRaiz nuevo = new rep_raiz;
      nuevo->dato = grupo; 
      nuevo->orden = visita->tope + 1;
      visita->array[ visita->tope + 1] = nuevo;  
      ++visita->tope;

      if (visita->invertido)
      {
        filtradoAscendenteInvertido(visita, visita->tope);
      } else filtradoAscendente(visita,  visita->tope); 
      }}}


int cantidadGruposTVisitaDia(TVisitaDia visitaDia){
  return visitaDia->tope;
}

void imprimirTVisitaDia(TVisitaDia visitaDia){

   if (visitaDia!= NULL)
 {
  printf("Visita para dia: ");
  imprimirTFecha(visitaDia->fecha);
  if (visitaDia->array[1] != NULL)
  {
    printf("\n\n");
  } else printf("\n");
  
  int escalar = 2;
  int nivel =2;
  for (int i = 1; visitaDia->array[i] != NULL; i++)
 {  
    if (i == 1)
    {
      int primero = 1;
      int orden = visitaDia->array[i]->orden;
      printf("Nivel %d\n",primero);
      float edad = edadPromedioTGrupoABB(visitaDia->array[i]->dato);
      printf("%d) Grupo %d con edad promedio %.2f\n",i,orden,edad);       
      imprimirTGrupoABB(visitaDia->array[i]->dato);
      
    } else if (i == 2)
    { 
      printf("\n");
      int segundo = 2;
      int orden = visitaDia->array[i]->orden;
      printf("Nivel %d\n",segundo); 
      float edad = edadPromedioTGrupoABB(visitaDia->array[i]->dato);
      printf("%d) Grupo %d con edad promedio %.2f\n",i,orden,edad);
      imprimirTGrupoABB(visitaDia->array[i]->dato);
    } else {

    if (i == 4)
    {  
      printf("\n");
      ++nivel;
      printf("Nivel %d\n",nivel); 
    } else if ((escalar*2)+1 == i)
    { 
      printf("\n");
      ++nivel;
      escalar = escalar *2;
      printf("Nivel %d\n",nivel); 
    }
    int orden = visitaDia->array[i]->orden;
    float edad = edadPromedioTGrupoABB(visitaDia->array[i]->dato);
    printf("%d) Grupo %d con edad promedio %.2f\n",i,orden,edad);
    imprimirTGrupoABB(visitaDia->array[i]->dato);
    }}}}


// Funcion auxliar para desencolar
void filtradoDescendente(int pos, TVisitaDia &visita)  {
   if (visita != NULL && pos*2<= visita->tope)
   {
    int  hijo = pos*2;
     // Me fijo si el arbol esta invertido
    if (visita->invertido == true)
    {
      if (hijo+1 <= visita->tope && visita->array[hijo+1] != NULL)
      {  
      if (hijo+1 <= visita->tope &&  (edadPromedioTGrupoABB(visita->array[hijo+1]->dato) > edadPromedioTGrupoABB(visita->array[hijo]->dato)))
     {
      ++hijo;
     } } 
         // Caso que el arbol no este invertido
      } else if (visita->invertido == false)
     {
        if (hijo+1 <= visita->tope && visita->array[hijo+1] != NULL)
      {  
         if (hijo+1 <= visita->tope &&  (edadPromedioTGrupoABB(visita->array[hijo+1]->dato) < edadPromedioTGrupoABB(visita->array[hijo]->dato)))
     {
      ++hijo;
     }}}
     // Swap de los elementos
     if (visita->array[hijo] != NULL)
     {
     TRaiz swap =  visita->array[hijo];
     visita->array[hijo] = visita->array[pos];
     visita->array[pos] = swap;
     filtradoDescendente(hijo, visita);
     }} 
     else if (visita != NULL && pos*2 > visita->tope) {
      while (pos+1 <= visita->tope)
      {
        TRaiz swap = visita->array[pos+1];
        visita->array[pos+1] = visita->array[pos];
        visita->array[pos] = swap;
        ++pos;
      }}}


TGrupoABB desencolarGrupoTVisitaDia(TVisitaDia &visitaDia){
    if (visitaDia != NULL)
    {
      if (visitaDia->array[1] !=  NULL)
      {
        TGrupoABB grupo = visitaDia->array[1]->dato;
        delete visitaDia->array[1];
        visitaDia->array[1] = NULL;
        filtradoDescendente(1,visitaDia);
        --visitaDia->tope;
        return grupo; 
      }
    } return NULL;
}

void liberarTVisitaDia(TVisitaDia &visitaDia){
  if (visitaDia != NULL)
  {
    for (int i = 1; i <= visitaDia->tope; i++)
    {
      liberarTGrupoABB(visitaDia->array[i]->dato);
      delete(visitaDia->array[i]);
      visitaDia->array[i] = NULL;
    }
    delete[] visitaDia->array;
    visitaDia->array = NULL;
    liberarTFecha(visitaDia->fecha);
    delete visitaDia;
    visitaDia = NULL;
  }}


void invertirPrioridadTVisitaDia(TVisitaDia &visita) {
  if (visita != NULL)
  {
    if (visita->array[1]!= NULL)
    {
      if (visita->invertido == true)
      {
        visita->invertido = false;
      } else visita->invertido = true;
     if (visita->tope> 1)
     {
      if (visita->invertido == true)
      {
        while ((edadPromedioTGrupoABB(visita->array[visita->tope]->dato) > edadPromedioTGrupoABB(visita->array[(visita->tope/2)]->dato)))
      {
        filtradoAscendenteInvertido(visita,visita->tope);
      }
      } else {
      while (edadPromedioTGrupoABB(visita->array[visita->tope]->dato) < edadPromedioTGrupoABB(visita->array[(visita->tope/2)]->dato))
      {
        filtradoAscendente(visita,visita->tope);
      }}}}}}


bool estaEnTVisitaDia(TVisitaDia visita, int id) {
  return visita->array[id] != NULL;
} 


float prioridadTVisitaDia(TVisitaDia visita, int id){
  if (visita!=NULL)
  {
    if (visita->array[1] != NULL)
    {
      return edadPromedioTGrupoABB(visita->array[visita->array[id]->orden]->dato);
    }}
  return 0.0; 
}


TGrupoABB masPrioritarioTVisitaDia(TVisitaDia visita){
	if (visita != NULL)
  {
    if (visita->array[1] != NULL)
    {
      return visita->array[1]->dato;
    }}
  return NULL;
}


int maxGruposTVisitaDia(TVisitaDia visita){
  return visita->maximo;
}


TFecha fechaTVisitaDia(TVisitaDia visitaDia){
  if (visitaDia!=NULL)
  {
     return visitaDia->fecha;
  } else return NULL;
}


